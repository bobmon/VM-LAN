The Link Layer Topology Discovery (LLTD) spec is located on www.microsoft.com/rally.  At this time of this writing, the explicit URL location is 
http://www.microsoft.com/whdc/Rally/LLTD-spec.mspx. 